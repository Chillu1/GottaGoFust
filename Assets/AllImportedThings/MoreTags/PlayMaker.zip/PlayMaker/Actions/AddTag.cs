using MoreTags;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("MoreTags")]
    [Tooltip("Add Tag to GameObject")]
    public class AddTag : FsmStateAction
    {
        [RequiredField]
        [Tooltip("The GameObject to add tag.")]
        public FsmOwnerDefault gameObject;

        [Tooltip("The tag add to GameObject.")]
        public FsmString tag;

        public override void Reset()
        {
            gameObject = null;
            tag = "";
        }

        public override void OnEnter()
        {
            DoAddTag();
            Finish();
        }

        private void DoAddTag()
        {
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            if (go == null) return;
            if (string.IsNullOrEmpty(tag.Value)) return;
            go.AddTag(tag.Value);
        }
    }
}
