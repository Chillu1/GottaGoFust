using MoreTags;
using System.Linq;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("MoreTags")]
    [Tooltip("Add Tags to GameObject")]
    public class AddTags : FsmStateAction
    {
        [RequiredField]
        [Tooltip("The GameObject to add tags.")]
        public FsmOwnerDefault gameObject;

        [ArrayEditor(VariableType.String)]
        [Tooltip("The tags add to GameObject.")]
        public FsmArray tags;

        public override void Reset()
        {
            gameObject = null;
            tags = null;
        }

        public override void OnEnter()
        {
            DoAddTags();
            Finish();
        }

        private void DoAddTags()
        {
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            if (go == null) return;
            foreach (var tag in tags.Values.OfType<string>())
                go.AddTag(tag);
        }
    }
}
