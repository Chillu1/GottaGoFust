using MoreTags;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("MoreTags")]
    [Tooltip("Change Tag in GameObject")]
    public class ChangeTag : FsmStateAction
    {
        [RequiredField]
        [Tooltip("The GameObject to Change tag.")]
        public FsmOwnerDefault gameObject;

        [Tooltip("The tag to Change.")]
        public FsmString tag;

        [Tooltip("The new tag.")]
        public FsmString newtag;

        public override void Reset()
        {
            gameObject = null;
            tag = "";
            newtag = "";
        }

        public override void OnEnter()
        {
            DoChangeTag();
            Finish();
        }

        private void DoChangeTag()
        {
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            if (go == null) return;
            if (string.IsNullOrEmpty(tag.Value)) return;
            if (string.IsNullOrEmpty(newtag.Value)) return;
            go.ChangeTag(tag.Value, newtag.Value);
        }
    }
}
