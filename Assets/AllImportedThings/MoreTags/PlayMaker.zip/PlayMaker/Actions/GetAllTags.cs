using MoreTags;
using System.Linq;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("MoreTags")]
    [Tooltip("Get all tags from Tag Manager.")]
    public class GetAllTags : FsmStateAction
    {
        [Tooltip("Get all tags with pattern.")]
        public FsmString pattern;

        [UIHint(UIHint.Variable)]
        [ArrayEditor(VariableType.String)]
        [Tooltip("Store all tags in a array.")]
        public FsmArray result;

        public override void Reset()
        {
            pattern = "";
            result = null;
        }

        public override void OnEnter()
        {
            DoGetAllTags();
            Finish();
        }

        private void DoGetAllTags()
        {
            string[] tags;

            if (string.IsNullOrEmpty(pattern.Value))
                tags = TagSystem.GetAllTags();
            else
                tags = ((TagNames)pattern.Value).ToArray();

            result.Reset();
            result.Resize(tags.Length);
            for (int i = 0; i < tags.Length; i++)
                result.Set(i, tags[i]);
        }
    }
}
