using MoreTags;
using System.Linq;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("MoreTags")]
    [Tooltip("Get all GameObjects with Tag Pattern.")]
    public class GetGameObjects : FsmStateAction
    {
        [Tooltip("Tag Pattern.")]
        public FsmString pattern;

        [ArrayEditor(VariableType.GameObject)]
        [Tooltip("Search from GameObjects.")]
        public FsmArray from;

        [ActionSection("Result")]

        [UIHint(UIHint.Variable)]
        [ArrayEditor(VariableType.GameObject)]
        [Tooltip("Store all GameObjects in a array.")]
        public FsmArray result;

        [UIHint(UIHint.Variable)]
        [Tooltip("Store GameObjects count.")]
        public FsmInt count;

        public override void Reset()
        {
            pattern = "*";
            from = null;
            result = null;
            count = 0;
        }

        public override void OnEnter()
        {
            DoGetGameObjects();
            Finish();
        }

        private void DoGetGameObjects()
        {
            var pat = pattern.Value;
            if (string.IsNullOrEmpty(pat))
                pat = "*";

            if (from.Length == 0)
                TagSystem.SearchFrom();
            else
                TagSystem.SearchFrom(from.Values.OfType<GameObject>());

            var list = ((TagPattern)pat).GameObjects();

            result.Reset();
            result.Resize(list.Length);
            for (int i = 0; i < list.Length; i++)
                result.Set(i, list[i]);
            count = list.Length;
        }
    }
}
