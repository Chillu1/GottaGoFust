﻿using MoreTags;
using System.Linq;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("MoreTags")]
    [Tooltip("Each time this action is called it gets the next GameObject match Tag Pattern.")]
    public class GetNextMatch : FsmStateAction
    {
        [Tooltip("Tag Pattern.")]
        public FsmString pattern;

        [ArrayEditor(VariableType.GameObject)]
        [Tooltip("Search from GameObjects.")]
        public FsmArray from;

        [Tooltip("Event to send if no match.")]
        public FsmEvent noMatchEvent;

        [Tooltip("Event to send to get the next match.")]
        public FsmEvent loopEvent;

        [Tooltip("Event to send when there are no more match.")]
        public FsmEvent finishedEvent;

        [ActionSection("Result")]

        [UIHint(UIHint.Variable)]
        [Tooltip("Store the next match GameObject variable.")]
        public FsmGameObject storeNextMatch;

        [UIHint(UIHint.Variable)]
        [Tooltip("Store GameObjects count.")]
        public FsmInt count;

        [UIHint(UIHint.Variable)]
        public FsmInt currentIndex;

        public override void Reset()
        {
            pattern = "*";
            from = null;
            noMatchEvent = null;
            loopEvent = null;
            finishedEvent = null;

            storeNextMatch = null;
            count = 0;
            currentIndex = null;
        }

        private string cachePattern = null;
        private GameObject[] gameObjects;
        private int nextIndex;

        public override void OnEnter()
        {
            DoGetNextMatch();
            Finish();
        }

        private void DoGetNextMatch()
        {
            if (cachePattern == null || cachePattern != pattern.Value)
            {
                cachePattern = pattern.Value;
                nextIndex = 0;

                var pat = cachePattern;
                if (string.IsNullOrEmpty(pat))
                    pat = "*";

                if (from.Length == 0)
                    TagSystem.SearchFrom();
                else
                    TagSystem.SearchFrom(from.Values.OfType<GameObject>());

                gameObjects = ((TagPattern)pat).GameObjects();
            }

            count = gameObjects.Length;

            if (noMatchEvent != null)
                if (gameObjects.Length == 0)
                {
                    nextIndex = 0;
                    Fsm.Event(noMatchEvent);
                    return;
                }

            if (nextIndex >= gameObjects.Length)
            {
                nextIndex = 0;
                currentIndex.Value = gameObjects.Length - 1;
                Fsm.Event(finishedEvent);
                return;
            }

            storeNextMatch.Value = gameObjects[nextIndex];

            if (nextIndex >= gameObjects.Length)
            {
                nextIndex = 0;
                currentIndex.Value = gameObjects.Length - 1;
                Fsm.Event(finishedEvent);
                return;
            }

            currentIndex.Value = nextIndex;
            nextIndex++;

            if (loopEvent != null)
            {
                Fsm.Event(loopEvent);
            }
        }
    }
}
