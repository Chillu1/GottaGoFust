using MoreTags;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("MoreTags")]
    [Tooltip("Get tags from GameObject")]
    public class GetTags : FsmStateAction
    {
        [RequiredField]
        [Tooltip("The GameObject to get tags.")]
        public FsmOwnerDefault gameObject;

        [Tooltip("Tag pattern.")]
        public FsmString pattern;

        [UIHint(UIHint.Variable)]
        [ArrayEditor(VariableType.String)]
        [Tooltip("The tags get from GameObject.")]
        public FsmArray result;

        public override void Reset()
        {
            gameObject = null;
            pattern = "";
            result = null;
        }

        public override void OnEnter()
        {
            DoGetTags();
            Finish();
        }

        private void DoGetTags()
        {
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            if (go == null) return;
            string[] tags;

            if (string.IsNullOrEmpty(pattern.Value))
                tags = go.GetTags();
            else
                tags = go.FindTags(pattern.Value);

            result.Reset();
            result.Resize(tags.Length);
            for (int i = 0; i < tags.Length; i++)
                result.Set(i, tags[i]);
        }
    }
}
