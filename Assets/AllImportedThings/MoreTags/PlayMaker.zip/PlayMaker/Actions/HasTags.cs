using MoreTags;
using System.Linq;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("MoreTags")]
    [Tooltip("Check GameObject has tags")]
    public class HasTags : FsmStateAction
    {
        [RequiredField]
        [Tooltip("The GameObject to check tags.")]
        public FsmOwnerDefault gameObject;

        [ArrayEditor(VariableType.String)]
        [Tooltip("The tags add to GameObject.")]
        public FsmArray tags;

        [Tooltip("Has both tags?")]
        public FsmBool both;

        [Tooltip("Event to send if is True.")]
        public FsmEvent isTrue;

        [Tooltip("Event to send if is False.")]
        public FsmEvent isFalse;

        public override void Reset()
        {
            gameObject = null;
            tags = null;
            both = false;
            isTrue = null;
            isFalse = null;
        }

        public override void OnEnter()
        {
            DoHasTags();
            Finish();
        }

        private void DoHasTags()
        {
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            if (go == null) return;

            bool value;
            if (both.Value)
                value = go.BothTags(tags.Values.OfType<string>().ToArray());
            else
                value = go.AnyTags(tags.Values.OfType<string>().ToArray());

            Fsm.Event(value ? isTrue : isFalse);
        }
    }
}
