﻿using MoreTags;
using System.Linq;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("MoreTags")]
    [Tooltip("Check GameObject Match Tag Pattern")]
    public class MatchPattern : FsmStateAction
    {
        [RequiredField]
        [Tooltip("The GameObject to check tags.")]
        public FsmOwnerDefault gameObject;

        [Tooltip("Tag Pattern.")]
        public FsmString pattern;

        [Tooltip("Event to send if is True.")]
        public FsmEvent isTrue;

        [Tooltip("Event to send if is False.")]
        public FsmEvent isFalse;

        public override void Reset()
        {
            gameObject = null;
            pattern = "*";
            isTrue = null;
            isFalse = null;
        }

        public override void OnEnter()
        {
            DoMatchPattern();
            Finish();
        }

        private void DoMatchPattern()
        {
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            if (go == null) return;

            var pat = pattern.Value;
            if (string.IsNullOrEmpty(pat))
                pat = "*";

            TagSystem.SearchFrom(new[] { go });
            var list = ((TagPattern)pat).GameObjects();
            TagSystem.SearchFrom();

            Fsm.Event(list.Any() ? isTrue : isFalse);
        }
    }
}
