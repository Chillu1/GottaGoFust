﻿using MoreTags;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("MoreTags")]
    [Tooltip("Remove Tag from GameObject")]
    public class RemoveTag : FsmStateAction
    {
        [RequiredField]
        [Tooltip("The GameObject to remove tag.")]
        public FsmOwnerDefault gameObject;

        [Tooltip("The tag remove from GameObject.")]
        public FsmString tag;

        public override void Reset()
        {
            gameObject = null;
            tag = "";
        }

        public override void OnEnter()
        {
            DoRemoveTag();
            Finish();
        }

        private void DoRemoveTag()
        {
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            if (go == null) return;
            if (string.IsNullOrEmpty(tag.Value)) return;
            go.RemoveTag(tag.Value);
        }
    }
}
