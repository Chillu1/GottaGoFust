﻿using MoreTags;
using System.Linq;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("MoreTags")]
    [Tooltip("Remove Tags from GameObject")]
    public class RemoveTags : FsmStateAction
    {
        [RequiredField]
        [Tooltip("The GameObject to remove tags.")]
        public FsmOwnerDefault gameObject;

        [ArrayEditor(VariableType.String)]
        [Tooltip("The tags remove from GameObject.")]
        public FsmArray tags;

        public override void Reset()
        {
            gameObject = null;
            tags = null;
        }

        public override void OnEnter()
        {
            DoRemoveTags();
            Finish();
        }

        private void DoRemoveTags()
        {
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            if (go == null) return;
            foreach (var tag in tags.Values.OfType<string>())
                go.RemoveTag(tag);
        }
    }
}
