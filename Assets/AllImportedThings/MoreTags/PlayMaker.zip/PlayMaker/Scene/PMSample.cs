﻿using MoreTags;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class PMSample : MonoBehaviour
{
    public PlayMakerFSM Fsm;

    public void SetParent(GameObject go, GameObject parent)
    {
        go.transform.SetParent(parent.transform);
    }

    public void SetGameObjectColor(GameObject go, string tag)
    {
        var mpb = new MaterialPropertyBlock();
        mpb.SetColor("_Color", TagSystem.GetTagColor(tag));
        go.GetComponent<MeshRenderer>().SetPropertyBlock(mpb);
    }

    public string GetTagLastName(string tag)
    {
        var tn = (TagName)tag;
        return tn.last;
    }

    public void SetUIText(GameObject go, string text)
    {
        var txt = go.GetComponent<Text>();
        txt.text = text;
    }

    public string GetInputField(GameObject go)
    {
        var input = go.GetComponent<InputField>();
        return input.text;
    }

    public void SetUIButtonOnClick(GameObject go, string text, bool gototarget)
    {
        var button = go.GetComponent<Button>();
        button.onClick.AddListener(() => DoOnClick(text, gototarget));
    }

    public void DoOnClick(string text, bool gototarget)
    {
        Fsm.FsmVariables.GetFsmString("ClickedTag").Value = text;
        Fsm.FsmVariables.GetFsmBool("GotoTarget").Value = gototarget;
        PlayMakerFSM.BroadcastEvent("Click");
    }

    public void GotoTarget(GameObject go, GameObject target, bool gototarget)
    {
        var agent = go.GetComponent<NavMeshAgent>();
        if (agent == null) return;
        Vector3 pos = target.transform.position;
        if (!gototarget)
            do
                pos = new Vector3(Random.Range(-4f, 4f), 0, Random.Range(-4f, 4f));
            while (Vector3.Distance(pos, target.transform.position) < 1.5f);
        agent.destination = pos;
    }
}